from matplotlib.cm import get_cmap
import matplotlib.pyplot as plt
import numpy as np
import pickle


def create_plots(len_scaler: float = 1.0) -> None:
    def _learner_plot(bank_balance_multiplier: float = 1.0, len_scaler: float = 1.0) -> None:
        training_profits = pickle.load(open(f'../results/data/learner_training_profits_0_{int(bank_balance_multiplier * 10)}.pickle', 'rb'))
        cmap = get_cmap('tab20')
        line_colors = [cmap(i % 20) for i in range(len(training_profits))]
        plt.figure(figsize=(4, 2))
        plt.grid()
        i = 0
        cutoff_idx = int(len_scaler * len(training_profits['Bank']))
        for name, profits in training_profits.items():
            color = line_colors[i]
            if name == 'Bank':
                plt.plot(profits[:cutoff_idx], label=name, color=color)
            else:
                plt.plot(profits[:cutoff_idx], color=color)
            i += 1
        plt.xlabel('Training Episode', fontsize=22, fontweight='bold')
        plt.ylabel('Profit', fontsize=22, fontweight='bold')
        plt.legend(loc='best')
        plt.xticks(fontsize=16)
        plt.yticks(fontsize=16)
        plt.savefig(f'../results/report/learner_training_profits_0_{int(bank_balance_multiplier * 10)}', bbox_inches='tight')
        plt.clf()

    def _variety_plot(bank_balance_multiplier: float = 1.0, len_scaler: float = 1.0) -> None:
        training_profits = pickle.load(open(f'../results/data/various_training_profits_0_{int(bank_balance_multiplier * 10)}.pickle', 'rb'))
        cmap = get_cmap('tab20')
        line_colors = [cmap(i % 20) for i in range(len(training_profits))]
        plt.figure(figsize=(4, 2))
        plt.grid()
        i = 0
        cutoff_idx = int(len_scaler * len(training_profits['Bank']))
        for name, profits in training_profits.items():
            color = line_colors[i]
            if name == 'Bank':
                plt.plot(profits[:cutoff_idx], label=name, color=color)
            else:
                plt.plot(profits[:cutoff_idx], color=color)
            i += 1
        plt.xlabel('Training Episode', fontsize=22, fontweight='bold')
        plt.ylabel('Profit', fontsize=22, fontweight='bold')
        plt.legend(loc='best')
        plt.xticks(fontsize=16)
        plt.yticks(fontsize=16)
        plt.savefig(f'../results/report/various_training_profits_0_{int(bank_balance_multiplier * 10)}', bbox_inches='tight')
        plt.clf()

    def _expert_plot(bank_balance_multiplier: float = 1.0, len_scaler: float = 1.0) -> None:
        training_profits = pickle.load(open(f'../results/data/expert_training_profits_0_{int(bank_balance_multiplier * 10)}.pickle', 'rb'))
        cmap = get_cmap('tab20')
        line_colors = [cmap(i % 20) for i in range(len(training_profits))]
        plt.figure(figsize=(4, 2))
        plt.grid()
        i = 0
        cutoff_idx = int(len_scaler * len(training_profits['Bank']))
        for name, profits in training_profits.items():
            color = line_colors[i]
            if name == 'Bank':
                plt.plot(profits[:cutoff_idx], label=name, color=color)
            else:
                plt.plot(profits[:cutoff_idx], color=color)
            i += 1
        plt.xlabel('Training Episode', fontsize=22, fontweight='bold')
        plt.ylabel('Profit', fontsize=22, fontweight='bold')
        plt.legend(loc='best')
        plt.xticks(fontsize=16)
        plt.yticks(fontsize=16)
        plt.savefig(f'../results/report/expert_training_profits_0_{int(bank_balance_multiplier * 10)}', bbox_inches='tight')
        plt.clf()

    _learner_plot(len_scaler=len_scaler)

    _variety_plot(len_scaler=len_scaler)

    _expert_plot(len_scaler=len_scaler)


if __name__ == "__main__":
    create_plots(len_scaler=0.5)
