from experiments.metrics_tracker import MetricsTracker
from runner.simulation_runner import SimulationRunner
from strategies.alegaatr import AlegAATr
from strategies.bar_movement import BarMovement
from strategies.beep_boop import BeepBoop
from strategies.bollinger_bands import BollingerBands
from strategies.choc import Choc
from strategies.cnn import CNNStrategy
from strategies.ensemble import Ensemble
from strategies.eee import EEE
from strategies.exp3 import EXP3
from strategies.keltner_channels import KeltnerChannels
from strategies.knn import KNNStrategy
from strategies.lstm import LstmStrategy
from strategies.lstm_mixture import LstmMixtureStrategy
from strategies.ma_crossover import MACrossover
from strategies.macd import MACD
from strategies.macd_key_level import MACDKeyLevel
from strategies.macd_stochastic import MACDStochastic
from strategies.mlp import MLPStrategy
from strategies.psar import PSAR
from strategies.random_forest import RandomForestStrategy
from strategies.rsi import RSI
from strategies.squeeze_pro import SqueezePro
from strategies.stochastic import Stochastic
from strategies.supertrend import Supertrend
from strategies.ucb import UCB
from utils.utils import CURRENCY_PAIRS, N_BANDIT_RUNS, TIME_FRAMES, YEARS


def test_strategies() -> None:
    # List of the final results to output
    test_results = []

    # Tracker to keep track of various metrics
    metrics_tracker = MetricsTracker()

    for currency_pair in CURRENCY_PAIRS:
        for time_frame in TIME_FRAMES:
            for year in YEARS[2:]:
                for _ in range(N_BANDIT_RUNS):
                    # List of all of the regular strategies
                    strategies = [BarMovement(), BeepBoop(), BollingerBands(), Choc(), KeltnerChannels(), MACrossover(),
                                  MACD(), MACDKeyLevel(), MACDStochastic(), PSAR(), RSI(), SqueezePro(), Stochastic(),
                                  Supertrend(), Ensemble(), AlegAATr(), UCB(), EXP3(), EEE()]

                    pair_time_frame_year_str = f'{currency_pair}_{time_frame}_{year}'
                    pair_time_frame_year_models_str = f'{currency_pair}_{time_frame}_{year - 1}'

                    print(pair_time_frame_year_str)

                    # Model names for the ML strategies (they need to load in pair-time-specific data)
                    cnn_model_name = f'CNN_{pair_time_frame_year_models_str}'
                    knn_model_name = f'KNN_{pair_time_frame_year_models_str}'
                    lstm_model_name = f'LSTM_{pair_time_frame_year_models_str}'
                    lstm_mixture_model_name = f'LstmMixture_{pair_time_frame_year_models_str}'
                    mlp_model_name = f'MLP_{pair_time_frame_year_models_str}'
                    rf_model_name = f'RandomForest_{pair_time_frame_year_models_str}'

                    # List of ML strategies
                    ml_strategies = [CNNStrategy(cnn_model_name), KNNStrategy(knn_model_name),
                                     LstmStrategy(lstm_model_name),
                                     LstmMixtureStrategy(lstm_mixture_model_name), MLPStrategy(mlp_model_name),
                                     RandomForestStrategy(rf_model_name)]

                    # List of all the strategies
                    all_strategies = strategies + ml_strategies

                    for strategy in all_strategies:
                        print(strategy.name)

                        result = SimulationRunner.run_simulation(strategy, currency_pair, time_frame, year, False,
                                                                 False,
                                                                 metrics_tracker)
                        print(result.net_reward)

                        # Update the final results
                        test_results.append((f'{strategy.name}_{pair_time_frame_year_str}', result))

                    print()

    # Save any metric data in order to perform analysis offline
    metrics_tracker.save_data([strategy.name for strategy in all_strategies])

    # Sort the results so that the most profitable results are first
    test_results.sort(key=lambda x: x[1].net_reward, reverse=True)

    # Print the results
    print('\n----------------------------------------------------------')
    print('FINAL TEST RESULTS (ordered from most profitable to least)')
    print('----------------------------------------------------------')

    for name, res in test_results:
        print(name)
        print(res)
        print()

    print('----------------------------------------------------------')
    print('----------------------------------------------------------')
    print('----------------------------------------------------------')


if __name__ == "__main__":
    test_strategies()
