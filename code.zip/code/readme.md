The phase1 folder contains code for our first experimentation phase.  The phase2 folder contains code for the second experimentation phase.  Finally, the bank folder contains code for the simple bank simulations we ran.  Note that we had to remove most of our saved data files in order to meet the supplementary material submission size requirement, but all of the original code files are included.

For the phase1 and phase2 folders, the layouts are similar:
    - aat: This folder contains code necessary for AAT (which AlegAATr relies on)
    - data: This folder contains code for reading in price data needed for running simulations
    - experiments: This folder contains code for running the algorithms, saving results, creating plots, etc.
    - genetics: This folder contains our genetic algorithm code
    - market_proxy: This folder contains code for handling proxy market details/calculations
    - models: This folder contains code for our price forecaster models
    - runner: This folder contains a single file that runs simulations
    - strategies: This folder contains all of the strategies/agents/algorithms that we implemented
    - utils: This final folder contains two files that serve as helper code

For the bank folder, the layout is the following:
    - agents: This folder contains the various agents we implemented
    - environment: This folder contains code to represent the simple market environment
    - plots: This folder contains code for generating the plots we presented in the paper
    - results: This folder contains data and plots that that are stored as simulations are run
    - simulations: This folder contains code for running different experiments/simulations